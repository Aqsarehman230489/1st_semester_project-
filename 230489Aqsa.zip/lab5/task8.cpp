#include<iostream>
using namespace std;
void main()
{
	int k,sum=0,n;
	cout << "Enter the number: ";
	cin >> n;
	for (k = 0; k <= n; k++)
	{
		sum = k+sum;
		cout << k << "+";
	}
	sum = 2 * sum;
	cout << ")*2=" << sum;
}