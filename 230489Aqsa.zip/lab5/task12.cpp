#include<iostream>
using namespace std;
void main()
{
	int i=0;
	cout << "Number divisible by 2: ";
	for (i = 1; i <= 100; i++)
	{
		if (i % 2 == 0)

			cout << i << "  ";
	}
		cout << "\n\nNumber divisible by 3: ";
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0)
		{
			cout << i << "  ";
		}
	}cout << "\n\nNumber divisible by 7: ";
	for (i = 1; i <= 100; i++)

	{
		if (i % 7 == 0)
			cout<< i<<"  ";
	}
}