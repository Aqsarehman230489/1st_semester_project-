#include<iostream>
using namespace std;
void main()
{
	char ch = ' ';
	do {
		cout << "enter a character";
		cin >> ch;

		if (ch <='A' || ch >='Z')
		{
			cout << "Uppercase letter\n";
		}
		else if (ch <='a' || ch >= 'z')
		{
			cout << "lowercase letter\n";
		}
		else if (ch >='0' || ch <='9')
		{
			cout << "digit\n";
		}
		else if (ch >= '!' || ch <= '~')
			cout << "symbol";
		else
			cout << "invalid";

	} while (ch != '@');
	{
		if (ch <= 'A' || ch >= 'Z')
		{
			cout << "Uppercase letter\n";
		}
		else if (ch <= 'a' || ch >= 'z')
		{
			cout << "lowercase letter\n";
		}
		else if (ch >= '0' || ch <= '9')
		{
			cout << "digit\n";
		}
		else if (ch >= '!' || ch <= '~')
			cout << "symbol";
		else
			cout << "invalid";
	}
}
