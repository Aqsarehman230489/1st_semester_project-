#include<iostream>
using namespace std;
void main()
{
	int i,sum=0;
	for (i = 1; i<= 100;i++)
	{
		sum = sum + i;
		
	}
	cout << sum;
}