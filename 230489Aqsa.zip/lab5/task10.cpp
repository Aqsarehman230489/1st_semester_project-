#include<iostream>
using namespace std;
void main()
{
	int n,sum=0,m;
	cout << "Enter the number: ";
	cin >> m;
	for (n = 0; n <=m; n++)
	{
		sum =n+sum;
	}
	sum = n/(n*3);
	cout<< sum;
}