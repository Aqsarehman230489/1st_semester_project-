#include<iostream>
using namespace std;
void main()
{
	int n,i,ans=0,sum;
	cout << "enter a number";
	cin >> n;
	for (i = 1; i <= n; i++)
	{
		ans += (i*i);
	}
	cout <<"Your result: "<< ans;
}
