#include<iostream>
using namespace std;
void main()
{
	char i=' ';
	char h=' ';
	cout <<"uppercase letter\tlowercase letter";
	for(i=65,h=97;i<=90;i++,h++)
	{
		 cout <<"\n\t"<<i<<"\t\t\t"<<h;
	}
}