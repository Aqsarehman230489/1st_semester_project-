#include<iostream>
using namespace std;
void main()
{
	
	cout << "number\t" << "square\t" << "cube\n";
	for (int i =1; i<= 15; i++)
	{
		cout<< i<<"\t"<<i * i <<"\t"<<i * i * i<<"\n";
	}
}