#include<iostream>
using namespace std;
void main()
{
        int binary;
        cout << "Enter a binary number: ";
        cin >> binary;
        int decimal = 0;
        int a = 0;
        while (binary > 0) 
        {
            int digit = binary % 10;
            decimal += digit * pow(2, a);
            binary /= 10;
            a++;
        }

        cout << "Decimal equivalent: " << decimal<<endl;
}