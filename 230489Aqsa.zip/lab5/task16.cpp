#include<iostream>
using namespace std;
void main()
{
	int num=0,i=0,digits=0;
	cout << "enter a number: ";
	cin >> num;
	while (num > 0)
	{
		i = num % 10;
		num = num / 10;
		digits++;
		cout << i << "\n";
	}
	cout << "number of digits: " << digits;

}
