#include<iostream>
using namespace std;
void main()
{
	int num=0,i=0,digits=0,rev=0,ans,a=0;
	cout << "enter a number: ";
	cin >> num;
	ans = num;
	while(num > 0)
	{   
		i = num % 10;
		num = num / 10;
		cout << i << "\n";
		rev = (rev * 10) + i;
		digits++;
	}
	if (digits ==5)
	{
		if (ans == rev)
		{
			cout << "Its a palindrome number.";
		}
		else if (ans != rev)
		{
			cout << "Sorry it is not a palindrome number. ";
		}
	}
}
