#include<iostream>
using namespace std;
void main()
{
	int a,i=1;
	cout << "Enter a number: ";
	cin >> a;
	if (a > 0)
		for (i = 1; i <= a; i++)
		{
			cout << i << " ";
		}
	else
		cout << "Invalid number";
}