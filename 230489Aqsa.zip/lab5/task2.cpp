#include<iostream>
using namespace std;
void main()
{
	int i,a;
	cout << "enter a num";
	cin >> a;
	for (i = 1; i <= 10; i++)
	{
		cout << a << "*" << i << "=" << a * i<<"\n";
	}
	
}