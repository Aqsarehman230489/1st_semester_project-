#include<iostream>
using namespace std;
void main()
{
	int a = 0,i=5,ans=0;
	for (i = 5; i <= 15&&i>=5; i++)
	{
		ans = 2 * i + i + 5;
		cout << "for x= " << i << "\tsolution= " << ans<<endl;
	}

}