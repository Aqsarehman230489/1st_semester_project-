#include<iostream>
using namespace std;
void main()
{
	int i,a,ans=1;
	cout << "enter a num";
	cin >> a;
	for (i =a;i>0 ; i--)
	{
		ans=ans * i;

	}
	cout <<ans;
}