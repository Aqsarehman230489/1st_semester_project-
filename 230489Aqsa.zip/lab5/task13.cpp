#include<iostream>
using namespace std;
void main()
{
	int i=1,sum=0;
    while(i>0)
	{
		cout << "Enter a number greater than zero(0) ";
		cin >> i;
		sum = i + sum;
	}
	cout <<"Your result: "<<sum;
}