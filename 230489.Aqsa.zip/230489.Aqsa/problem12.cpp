#include<iostream>
using namespace std;
void main()
{
	float volume = 0;
	int r = 0, h = 0;
	cout << "Enter radius: ";
	cin >> r;
	cout << "\nEnter height:  ";
	cin >> h;
	volume = 1 / 3.0*(3.14 * r * r * h);
	if (volume >= 100&& (r % 2) == 0)
	{
			cout << "acha cone";
	}
	else
		cout << "ganda cone";

}