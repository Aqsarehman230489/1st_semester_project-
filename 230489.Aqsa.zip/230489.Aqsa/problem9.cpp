#include<iostream>
using namespace std;
void main()
{
	int mileage = 0;
	cout << "Enter mileage per gallon: ";
	cin >> mileage;
	if (mileage >= 40)
		cout << "your car has got excellent mileage";
	else
		cout << "your car has got poor mileage";
}