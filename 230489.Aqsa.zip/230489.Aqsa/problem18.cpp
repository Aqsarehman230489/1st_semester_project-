#include<iostream>
using namespace std;
void main()
{
	double bavg = 0, bowavg = 0, bsr = 0, er = 0;
	char tob;
	cout << "Batting average: ";
	cin >> bavg;
	cout << "Bowling average: ";
	cin >> bowavg;
	cout << "Type of bowler(f for fast bowler and s for spinner): ";
	cin >> tob;
	cout << "Batting strike rate: ";
	cin >> bsr;
	cout << "Economy rate: ";
	cin >> er;
	if (bavg >= 45 && bowavg >= 60) //for batsman
	{
		cout << "\nCategory: Batsman";
		if (bavg >= 50 && bsr >= 70)
			cout << "\nPlays in tests";
		else
			cout << "\nPlays in ODLs";
	}
	else if (bowavg <= 30 && bavg <= 20) //for all types of bowler
	{
		cout << "\ncategory: Bowler";
		if (tob == 's' && bowavg >= 20 && bowavg <= 30 && er <= 3) //spiner
			cout << "\nPlays in test match";
		else
			cout << "\nPlays in ODIs";
		if (tob == 'f' && bowavg >= 20 && bowavg <= 30 && er <= 5 && er > 3)//fast bowler
			cout << "\nPlays in ODIs";
		else
			cout << "\nPlays in test";
	}
	else if (bavg >= 40 && bowavg <= 30) //for all rounders
	{
		if (bavg >= 40 && bowavg <= 25)
			cout << "\nPlays in test match";
		else
			cout << "\nPlays in ODIs";
	}
	else
		cout << "Player should be part of the reserves";
}