#include<iostream>
using namespace std;
void main()
{
	int mileage = 0;
	cout << "Enter mileage per gallon";
	cin >> mileage;
	mileage >= 40 ? cout << "Your car has got excellent mileage" : cout << "Your car has got poor mileage";
}