#include<iostream>
using namespace std;
void main()
{
	float num;
	cout << "Enter your percentage: ";
	cin >> num;
	if (num > 80 && num <= 100)
		cout << "Grade A\nRemarks: cheetah bacha";
	else if (num > 70 && num <= 80)
		cout << "Grade A-\nRemarks: acha bacha";
	else if (num > 60 && num <= 70)
		cout << "Grade B+\nRemarks: theek bacha";
	else if (num > 50 && num <= 60)
		cout << "Grade B\nRemarks: guzara bacha";
	else if (num > 40 && num <= 50)
		cout << "Grade B-\nRemarks: matha bacha";
	else if (num > 33 && num <= 40)
		cout << "Grade c+\nRemarks: farig bacha";
	else if (num <= 33)
		cout << "Grade F\nRemarks: koi haal nhi";
	else
		cout << "percentage is out of range";

}