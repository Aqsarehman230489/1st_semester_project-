#include<iostream>
using namespace std;
void main()
{
	int ibalance = 0,newbalance=0;
	cout << "Enter initial balance: ";
	cin >> ibalance;
	ibalance > 5000 ? cout <<"Your balance: " << (newbalance = ibalance * 1.10) : cout << "\nSorry you are not eligible for bouns";
}