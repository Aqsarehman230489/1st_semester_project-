#include<iostream>
using namespace std;
void main()
{
	int a, b;
	cout << "Enter num a";
	cin >> a;
	cout << "enter num b";
	cin>> b;
	if (a % 2 == 0 && b % 2 == 0)
	{
		cout << "you have entered two even number";
	}
	else if (a % 2 != 0 && b % 2 != 0)
	{
		cout << "you have entered two odd numbers";
	}
	else if (a %2 == 0 || b % 2 == 0)
	{
		cout << "you have entered one even and one odd num";
	}
	else
		cout << "invalid num";
}