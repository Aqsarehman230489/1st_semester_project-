#include <iostream>
using namespace std;
void main()
{
	char temp =' ', hdt =' ';
	cout << "Enter temperature: ";
	cin >> temp;
	cout << "\nEnter humidity: ";
	cin >> hdt;
	if (temp == 'w')
	{
		if (hdt == 'd')
			cout << "\nplay tennis";
		if (hdt == 'h')
			cout << "\nswim";
	}
	if (temp == 'c')
	{
		if (hdt == 'd')
			cout << "play basketball";
		if (hdt == 'h')
			cout << "watch TV";
	}
	if (temp != 'w' || temp != 'c')
	{
		cout << "Invalid";
	}
}