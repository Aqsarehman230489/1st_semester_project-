#include<iostream>
using namespace std;
void main()
{
	int a=0;
	cout << "Enter a number";
	cin >> a;
	if (a> 50)
	{
		if (a % 5 == 0)
		{
			cout << "\nNumber is greater than 50 is a multiple of 5";
		}
		else
			cout << "\nNumber is greater than 50 and is not a multiple of 5";
		
	}
	else 
	{
		if (a % 5 != 0)
			cout << "\nNumber is less than 50 but is not a multiple of 5";
		else
			cout << "\nNumber is less than 50 and a multiple of 5";
	}
}