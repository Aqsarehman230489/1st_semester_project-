#include<iostream>
using namespace std;
void main()
{
	int a=0, b=0, c=0;
	cout << "enter a num";
	cin >> a;
	cout << "\nenter b num";
	cin >> b;
	cout << "\nenter c num";
	cin >> c;
	if (a > b&&a>c)
	{
			cout << "num a is mximum";
	}
	else if (b > a&&b>c)
	{
			cout << "num b is maximum";
	}
	else
	{
		cout << "num c is maximum";
	}

}