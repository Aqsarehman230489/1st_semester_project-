#include<iostream>
using namespace std;
void main()
{
	int num;
	cout << "enter a num";
	cin >> num;
	{if (num > 50)
		cout << "num is greater than 50";
	else 
		cout<< "num is less than 50";

	}
}