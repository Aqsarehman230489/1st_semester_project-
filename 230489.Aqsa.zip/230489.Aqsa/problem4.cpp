#include<iostream>
using namespace std;
void main()
{
	float balance=0,newvalue=0 ,orignal=0;
	cout << "enter initial balance";
	cin >> balance;
	if (balance > 5000)
	{
		newvalue = orignal * 1.10;
		cout << "your bonus" << newvalue;

	}
	else
	{
		cout << "sorry you are not eligible for balance";
	}
}