#include<iostream>
using namespace std;
void main()
{
	int a, b,ans1=0,ans2=0, remainder=0;
	cout << "enter first num";
	cin >> a;
	cout << "enter second num";
	cin >> b;
	remainder = a % b;
	if ((a % b) == 0)
	{
		ans1 = a / b;
		cout << "The number a is completely divisible by b\nThe quotient is " << ans1 << "\nThere is no remainder";
	}
	else
	{
		ans2 = a / b;
		cout << "\nThe number is not completely divisible by b\nThe quotient is " << ans2 << "\nThe remainder is" << remainder;

	}
}