#include<iostream>
using namespace std;
void main()
{
	int num = 0, ans = 0;
	cout << "Enter a num: ";
	cin >> num;
	if (num %2==0)
		cout << "EVEN";
	else
		cout << "ODD";
}
