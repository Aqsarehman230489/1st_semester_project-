#include<iostream>
using namespace std;
void main()
{
	int noise=0;
	cout << "\nENTER THE NOISE LEVEL:";
	cin >> noise;
	if (noise <= 50)
	{
		cout << "\nLower quite";
	}
	else if (noise >= 51 && noise <= 70)
		cout << "\nIntrusive";
	else if (noise >= 71 && noise <= 90)
		cout << "\nAnnoying";
	else if (noise >= 91 && noise <= 100)
		cout << "\nVery annoying";
	else if (noise > 110)
		cout << "\nUncomfortable";
}