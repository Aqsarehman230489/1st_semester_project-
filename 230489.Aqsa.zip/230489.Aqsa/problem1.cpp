#include<iostream>
using namespace std;
void main()
{
	int num;
	cout << "\nenter a num";
	cin >> num;
	num > 50 ? cout << "the num is greater than 50" : cout << "the num is less than 50";
}
