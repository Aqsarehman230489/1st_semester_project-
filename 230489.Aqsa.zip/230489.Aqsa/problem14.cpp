#include<iostream>
using namespace std;
void main()
{
	int a;
	cout << "Enter a number from 1 to 100 :";
	cin >> a;
	if (a<=100&&a>=1)
	{
		if (a == 50)
		{
			cout << "\nthe number is in range and its equal to 50";
		}
		else if (a<50)
			cout << "\nThe number is in range and less than 50";
		else
			cout << "\nThe number is in range and is greater than 50";
		
	}
	else
	{
		cout << "\nThe number is out of range";
	}
}