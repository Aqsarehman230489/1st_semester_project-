#include<iostream>
using namespace std;
void main()
{
	int num = 0, ans = 0;
	cout << "enter a num";
	cin >> num;
	if ((num & 1) == 0)
		cout << "The num is even";
	else
		cout << "The num is odd";
}
